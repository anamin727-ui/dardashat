module dardashat

go 1.23
