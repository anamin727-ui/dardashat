package main

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"embed"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

//go:embed web/*
var assets embed.FS

const maxOnline = 20
const sessionTTL = 7 * 24 * time.Hour
const onlineTTL = 50 * time.Second
const maxMessageRunes = 800

type User struct {
	Name        string `json:"name"`
	Salt        string `json:"salt"`
	Hash        string `json:"hash"`
	Created     int64  `json:"created"`
	BannedUntil int64  `json:"bannedUntil,omitempty"`
}
type Msg struct {
	ID   int64  `json:"id"`
	Room string `json:"room,omitempty"`
	From string `json:"from"`
	To   string `json:"to,omitempty"`
	Text string `json:"text"`
	At   int64  `json:"at"`
}
type Store struct {
	Users    map[string]User `json:"users"`
	Messages []Msg           `json:"messages"`
	NextID   int64           `json:"nextId"`
}
type Session struct {
	User     string
	Seen     time.Time
	Room     string
	LastSent []time.Time
}
type App struct {
	mu          sync.Mutex
	store       Store
	sessions    map[string]*Session
	adminTokens map[string]time.Time
	adminCode   string
	dir         string
	path        string
	failed      map[string][]time.Time
}

var rooms = []string{"العامة", "التعارف", "الألعاب", "التقنية"}

func main() {
	log.SetFlags(log.Ltime)
	app, err := newApp()
	if err != nil {
		log.Fatal(err)
	}
	mux := http.NewServeMux()
	root, err := fs.Sub(assets, "web")
	if err != nil {
		log.Fatal(err)
	}
	mux.Handle("/", http.FileServer(http.FS(root)))
	mux.HandleFunc("/api/auth", app.auth)
	mux.HandleFunc("/api/me", app.me)
	mux.HandleFunc("/api/logout", app.logout)
	mux.HandleFunc("/api/state", app.state)
	mux.HandleFunc("/api/send", app.send)
	mux.HandleFunc("/api/delete", app.deleteMessage)
	mux.HandleFunc("/api/admin/login", app.adminLogin)
	mux.HandleFunc("/api/admin/action", app.adminAction)
	mux.HandleFunc("/api/admin/status", app.adminStatus)
	mux.HandleFunc("/api/health", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "GET" {
			http.Error(w, "method", 405)
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true, "version": "2.0", "app": "دردشات", "rooms": 4, "maxOnline": maxOnline})
	})
	handler := secureHeaders(mux)
	port := os.Getenv("PORT")
	if port == "" {
		port = os.Getenv("ALIWI_PORT")
	}
	if port == "" {
		port = "8787"
	}
	var listener net.Listener
	for i := 0; i < 10; i++ {
		n, _ := strconv.Atoi(port)
		if n < 1 || n > 65535 {
			log.Fatal("Invalid ALIWI_PORT")
		}
		listener, err = net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", n+i))
		if err == nil {
			port = strconv.Itoa(n + i)
			break
		}
	}
	if listener == nil {
		log.Fatal("تعذر فتح منفذ. أغلق النسخة السابقة من البرنامج.")
	}
	url := "http://localhost:" + port + "/"
	fmt.Println("\n=========================================================")
	fmt.Println("     دردشات ♥  |  أربع غرف  |  عشرون شخصاً")
	fmt.Println("=========================================================")
	fmt.Println("افتح على هذا الكمبيوتر: ", url)
	for _, ip := range localIPs() {
		if os.Getenv("DARDASHAT_CLOUD") != "1" {
			fmt.Println("رابط الأجهزة على نفس الواي فاي: http://" + ip + ":" + port + "/")
		}
	}
	if os.Getenv("DARDASHAT_CLOUD") != "1" {
		fmt.Println("رمز إدارة الغرف (احتفظ به ولا تشاركه):", app.adminCode)
	}
	fmt.Println("البيانات محفوظة في:", app.dir)
	if os.Getenv("DARDASHAT_CLOUD") != "1" {
		fmt.Println("اترك هذه النافذة مفتوحة حتى تبقى الدردشة تعمل.")
	}
	fmt.Println("للإيقاف: اضغط Ctrl+C أو أغلق هذه النافذة.")
	fmt.Println("=========================================================")
	if os.Getenv("ALIWI_NO_BROWSER") != "1" && os.Getenv("DARDASHAT_CLOUD") != "1" {
		go func() { time.Sleep(500 * time.Millisecond); openBrowser(url) }()
	}
	srv := &http.Server{Handler: handler, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second, WriteTimeout: 20 * time.Second, IdleTimeout: 60 * time.Second, MaxHeaderBytes: 1 << 20}
	log.Fatal(srv.Serve(listener))
}
func secureHeaders(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'")
		if strings.HasPrefix(r.URL.Path, "/api/") {
			w.Header().Set("Cache-Control", "no-store")
		}
		h.ServeHTTP(w, r)
	})
}
func openBrowser(url string) {
	var c *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		c = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		c = exec.Command("open", url)
	default:
		c = exec.Command("xdg-open", url)
	}
	_ = c.Start()
}
func localIPs() []string {
	interfaces, _ := net.Interfaces()
	out := []string{}
	seen := map[string]bool{}
	for _, iface := range interfaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addresses, _ := iface.Addrs()
		for _, addr := range addresses {
			var ip net.IP
			switch t := addr.(type) {
			case *net.IPNet:
				ip = t.IP
			case *net.IPAddr:
				ip = t.IP
			}
			if ip4 := ip.To4(); ip4 != nil && !ip4.IsLoopback() && !seen[ip4.String()] {
				out = append(out, ip4.String())
				seen[ip4.String()] = true
			}
		}
	}
	return out
}
func dataDir() string {
	if path := strings.TrimSpace(os.Getenv("DARDASHAT_DATA_DIR")); path != "" {
		return path
	}
	base, err := os.UserConfigDir()
	if err != nil || base == "" {
		base = "."
	}
	return filepath.Join(base, "Dardashat")
}
func newApp() (*App, error) {
	if os.Getenv("DARDASHAT_CLOUD") == "1" && len(strings.TrimSpace(os.Getenv("DARDASHAT_ADMIN_CODE"))) < 16 {
		return nil, fmt.Errorf("يجب تعيين DARDASHAT_ADMIN_CODE برمز قوي طوله 16 حرفاً على الأقل لتشغيل الاستضافة العالمية")
	}
	dir := dataDir()
	if err := os.MkdirAll(dir, 0700); err != nil {
		return nil, err
	}
	a := &App{dir: dir, path: filepath.Join(dir, "data.json"), sessions: map[string]*Session{}, adminTokens: map[string]time.Time{}, failed: map[string][]time.Time{}, store: Store{Users: map[string]User{}, Messages: []Msg{}, NextID: 1}}
	if raw, err := os.ReadFile(a.path); err == nil {
		if err := json.Unmarshal(raw, &a.store); err != nil {
			return nil, fmt.Errorf("تعذر قراءة البيانات: %w", err)
		}
	} else if !errors.Is(err, os.ErrNotExist) {
		return nil, err
	}
	if a.store.Users == nil {
		a.store.Users = map[string]User{}
	}
	if a.store.Messages == nil {
		a.store.Messages = []Msg{}
	}
	if a.store.NextID < 1 {
		a.store.NextID = 1
	}
	codePath := filepath.Join(dir, "admin_code.txt")
	code, err := os.ReadFile(codePath)
	if err == nil && len(strings.TrimSpace(string(code))) >= 12 {
		a.adminCode = strings.TrimSpace(string(code))
	} else {
		a.adminCode = randText(18)
		if err := os.WriteFile(codePath, []byte(a.adminCode), 0600); err != nil {
			return nil, err
		}
	}
	if code := strings.TrimSpace(os.Getenv("DARDASHAT_ADMIN_CODE")); len(code) >= 16 {
		a.adminCode = code
	}
	return a, nil
}
func randText(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return base64.RawURLEncoding.EncodeToString(b)
}
func passHash(password, salt string) string {
	sb, _ := hex.DecodeString(salt)
	pass := []byte(password)
	var final []byte
	for block := 1; block <= 1; block++ {
		mac := hmac.New(sha256.New, pass)
		mac.Write(sb)
		mac.Write([]byte{0, 0, 0, byte(block)})
		u := mac.Sum(nil)
		t := append([]byte{}, u...)
		for j := 1; j < 70000; j++ {
			mac = hmac.New(sha256.New, pass)
			mac.Write(u)
			u = mac.Sum(nil)
			for k := range t {
				t[k] ^= u[k]
			}
		}
		final = append(final, t...)
	}
	return hex.EncodeToString(final)
}
func saveLocked(a *App) error {
	raw, err := json.MarshalIndent(a.store, "", "  ")
	if err != nil {
		return err
	}
	tmp := a.path + ".tmp"
	if err = os.WriteFile(tmp, raw, 0600); err != nil {
		return err
	}
	if err = os.Rename(tmp, a.path); err != nil {
		_ = os.Remove(a.path)
		return os.Rename(tmp, a.path)
	}
	return nil
}
func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func problem(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]any{"error": msg})
}
func decode(w http.ResponseWriter, r *http.Request, v any) bool {
	if r.Method != "POST" {
		problem(w, 405, "الطلب غير مدعوم")
		return false
	}
	if !strings.HasPrefix(r.Header.Get("Content-Type"), "application/json") {
		problem(w, 415, "يجب إرسال JSON")
		return false
	}
	r.Body = http.MaxBytesReader(w, r.Body, 16384)
	defer r.Body.Close()
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(v); err != nil {
		problem(w, 400, "بيانات غير صحيحة")
		return false
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		problem(w, 400, "طلب غير صحيح")
		return false
	}
	return true
}
func (a *App) userFor(r *http.Request) (string, string, bool) {
	c, err := r.Cookie("dardashat_sid")
	if err != nil {
		return "", "", false
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	s, ok := a.sessions[c.Value]
	if !ok {
		return "", "", false
	}
	if time.Since(s.Seen) > sessionTTL {
		delete(a.sessions, c.Value)
		return "", "", false
	}
	if time.Since(s.Seen) > onlineTTL && len(a.onlineLocked()) >= maxOnline {
		// The member was away and all 20 active places are now taken.
		return "", "", false
	}
	user := a.store.Users[s.User]
	if user.BannedUntil > time.Now().Unix() {
		delete(a.sessions, c.Value)
		return "", "", false
	}
	s.Seen = time.Now()
	return s.User, c.Value, true
}
func (a *App) require(w http.ResponseWriter, r *http.Request) (string, string, bool) {
	u, s, ok := a.userFor(r)
	if !ok {
		problem(w, 401, "انتهت الجلسة أو لم تسجّل الدخول")
		return "", "", false
	}
	return u, s, true
}
func (a *App) onlineLocked() map[string]string {
	now := time.Now()
	online := map[string]string{}
	for sid, s := range a.sessions {
		if now.Sub(s.Seen) > sessionTTL {
			delete(a.sessions, sid)
			continue
		}
		if now.Sub(s.Seen) > onlineTTL {
			continue
		}
		if user, ok := a.store.Users[s.User]; ok && user.BannedUntil <= now.Unix() {
			online[s.User] = s.Room
		}
	}
	return online
}
func cleanName(s string) string {
	s = strings.TrimSpace(s)
	s = strings.Join(strings.Fields(s), " ")
	return s
}
func validName(s string) bool {
	if utf8.RuneCountInString(s) < 2 || utf8.RuneCountInString(s) > 22 {
		return false
	}
	for _, r := range s {
		if r < ' ' || r == 127 {
			return false
		}
	}
	return true
}
func userKey(s string) string { return strings.ToLower(s) }
func (a *App) rateFailedLocked(ip string) bool {
	now := time.Now()
	arr := a.failed[ip]
	out := arr[:0]
	for _, t := range arr {
		if now.Sub(t) < 5*time.Minute {
			out = append(out, t)
		}
	}
	a.failed[ip] = out
	return len(out) >= 12
}
func remoteIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}
func (a *App) auth(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Name     string `json:"name"`
		Password string `json:"password"`
	}
	if !decode(w, r, &in) {
		return
	}
	in.Name = cleanName(in.Name)
	if !validName(in.Name) {
		problem(w, 400, "الاسم يجب أن يكون من 2 إلى 22 حرفاً")
		return
	}
	if len(in.Password) < 6 || len(in.Password) > 128 {
		problem(w, 400, "كلمة المرور من 6 إلى 128 حرفاً")
		return
	}
	key := userKey(in.Name)
	a.mu.Lock()
	defer a.mu.Unlock()
	ip := remoteIP(r)
	if a.rateFailedLocked(ip) {
		problem(w, 429, "محاولات كثيرة، انتظر قليلاً")
		return
	}
	u, exists := a.store.Users[key]
	if exists {
		calc := passHash(in.Password, u.Salt)
		if subtle.ConstantTimeCompare([]byte(calc), []byte(u.Hash)) != 1 {
			a.failed[ip] = append(a.failed[ip], time.Now())
			problem(w, 401, "الاسم موجود وكلمة المرور غير صحيحة")
			return
		}
		if u.BannedUntil > time.Now().Unix() {
			problem(w, 403, "الحساب موقوف مؤقتاً")
			return
		}
	} else {
		if len(a.store.Users) >= 300 {
			problem(w, 403, "بلغت الحسابات الحد الأقصى")
			return
		}
		saltRaw := make([]byte, 16)
		_, _ = rand.Read(saltRaw)
		salt := hex.EncodeToString(saltRaw)
		u = User{Name: in.Name, Salt: salt, Hash: passHash(in.Password, salt), Created: time.Now().Unix()}
		a.store.Users[key] = u
		if err := saveLocked(a); err != nil {
			delete(a.store.Users, key)
			problem(w, 500, "تعذر حفظ الحساب")
			return
		}
	}
	// A second login for the same account replaces the old session.
	online := a.onlineLocked()
	if _, already := online[key]; !already && len(online) >= maxOnline {
		problem(w, 403, "الغرف ممتلئة حالياً (20/20)، حاول لاحقاً")
		return
	}
	for tok, ss := range a.sessions {
		if ss.User == key {
			delete(a.sessions, tok)
		}
	}
	tok := randText(32)
	a.sessions[tok] = &Session{User: key, Room: rooms[0], Seen: time.Now()}
	http.SetCookie(w, &http.Cookie{Name: "dardashat_sid", Value: tok, Path: "/", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: 7 * 24 * 60 * 60, Secure: r.TLS != nil || strings.EqualFold(r.Header.Get("X-Forwarded-Proto"), "https")})
	writeJSON(w, 200, map[string]any{"ok": true, "name": u.Name, "newAccount": !exists})
}
func (a *App) me(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		problem(w, 405, "method")
		return
	}
	user, _, ok := a.userFor(r)
	if !ok {
		problem(w, 401, "لا توجد جلسة")
		return
	}
	a.mu.Lock()
	name := a.store.Users[user].Name
	a.mu.Unlock()
	writeJSON(w, 200, map[string]any{"name": name})
}
func (a *App) logout(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		problem(w, 405, "method")
		return
	}
	c, err := r.Cookie("dardashat_sid")
	if err == nil {
		a.mu.Lock()
		delete(a.sessions, c.Value)
		a.mu.Unlock()
	}
	http.SetCookie(w, &http.Cookie{Name: "dardashat_sid", Value: "", Path: "/", MaxAge: -1, HttpOnly: true, SameSite: http.SameSiteStrictMode})
	writeJSON(w, 200, map[string]any{"ok": true})
}
func roomValid(s string) bool {
	for _, r := range rooms {
		if r == s {
			return true
		}
	}
	return false
}
func (a *App) state(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		problem(w, 405, "method")
		return
	}
	user, sid, ok := a.require(w, r)
	if !ok {
		return
	}
	room := r.URL.Query().Get("room")
	if !roomValid(room) {
		room = rooms[0]
	}
	peerKey := userKey(r.URL.Query().Get("peer"))
	a.mu.Lock()
	defer a.mu.Unlock()
	if session, ok := a.sessions[sid]; ok {
		session.Room = room
	}
	online := a.onlineLocked()
	members := []map[string]any{}
	for id, rname := range online {
		if u, ok := a.store.Users[id]; ok {
			members = append(members, map[string]any{"name": u.Name, "room": rname})
		}
	}
	sort.Slice(members, func(i, j int) bool { return fmt.Sprint(members[i]["name"]) < fmt.Sprint(members[j]["name"]) })
	var messages []Msg = []Msg{}
	inbox := map[string]Msg{}
	counts := map[string]int{}
	for _, v := range rooms {
		counts[v] = 0
	}
	for _, rname := range online {
		counts[rname]++
	}
	for _, msg := range a.store.Messages {
		if msg.To == "" {
			if peerKey == "" && msg.Room == room {
				messages = append(messages, msg)
			}
		} else if msg.From == user || msg.To == user {
			other := msg.From
			if other == user {
				other = msg.To
			}
			inbox[other] = msg
			if peerKey != "" && other == peerKey {
				messages = append(messages, msg)
			}
		}
	}
	if len(messages) > 100 {
		messages = messages[len(messages)-100:]
	}
	dm := []map[string]any{}
	for k, msg := range inbox {
		name := k
		if p, ok := a.store.Users[k]; ok {
			name = p.Name
		}
		dm = append(dm, map[string]any{"name": name, "last": msg})
	}
	sort.Slice(dm, func(i, j int) bool { return dm[i]["last"].(Msg).ID > dm[j]["last"].(Msg).ID })
	name := a.store.Users[user].Name
	writeJSON(w, 200, map[string]any{"me": name, "rooms": rooms, "room": room, "count": len(online), "capacity": maxOnline, "counts": counts, "members": members, "messages": messages, "inbox": dm, "now": time.Now().Unix()})
}
func (a *App) send(w http.ResponseWriter, r *http.Request) {
	user, sid, ok := a.require(w, r)
	if !ok {
		return
	}
	var in struct {
		Room string `json:"room"`
		To   string `json:"to"`
		Text string `json:"text"`
	}
	if !decode(w, r, &in) {
		return
	}
	in.Text = strings.TrimSpace(in.Text)
	n := utf8.RuneCountInString(in.Text)
	if n < 1 || n > maxMessageRunes {
		problem(w, 400, "الرسالة يجب أن تكون من 1 إلى 800 حرف")
		return
	}
	peer := userKey(cleanName(in.To))
	if peer == "" && !roomValid(in.Room) {
		problem(w, 400, "غرفة غير صحيحة")
		return
	}
	if peer == user {
		problem(w, 400, "لا يمكنك مراسلة نفسك")
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	session, ok := a.sessions[sid]
	if !ok {
		problem(w, 401, "انتهت الجلسة")
		return
	}
	now := time.Now()
	recent := session.LastSent[:0]
	for _, t := range session.LastSent {
		if now.Sub(t) < 8*time.Second {
			recent = append(recent, t)
		}
	}
	if len(recent) >= 5 {
		session.LastSent = recent
		problem(w, 429, "تمهّل قليلاً قبل إرسال المزيد")
		return
	}
	session.LastSent = append(recent, now)
	if peer != "" {
		if _, exists := a.store.Users[peer]; !exists {
			problem(w, 404, "هذا المستخدم غير موجود")
			return
		}
	}
	msg := Msg{ID: a.store.NextID, Room: in.Room, From: user, To: peer, Text: in.Text, At: now.UnixMilli()}
	a.store.NextID++
	a.store.Messages = append(a.store.Messages, msg)
	if len(a.store.Messages) > 2400 {
		a.store.Messages = a.store.Messages[len(a.store.Messages)-2400:]
	}
	if err := saveLocked(a); err != nil {
		a.store.Messages = a.store.Messages[:len(a.store.Messages)-1]
		a.store.NextID--
		problem(w, 500, "تعذر حفظ الرسالة")
		return
	}
	writeJSON(w, 200, map[string]any{"ok": true, "message": msg})
}
func (a *App) deleteMessage(w http.ResponseWriter, r *http.Request) {
	user, _, ok := a.require(w, r)
	if !ok {
		return
	}
	var in struct {
		ID int64 `json:"id"`
	}
	if !decode(w, r, &in) {
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	for i, m := range a.store.Messages {
		if m.ID == in.ID {
			if m.From != user {
				problem(w, 403, "يمكنك حذف رسائلك فقط")
				return
			}
			if time.Since(time.UnixMilli(m.At)) > 10*time.Minute {
				problem(w, 403, "انتهت مدة حذف الرسالة (10 دقائق)")
				return
			}
			a.store.Messages = append(a.store.Messages[:i], a.store.Messages[i+1:]...)
			if err := saveLocked(a); err != nil {
				problem(w, 500, "تعذر الحذف")
				return
			}
			writeJSON(w, 200, map[string]any{"ok": true})
			return
		}
	}
	problem(w, 404, "الرسالة غير موجودة")
}
func (a *App) checkAdmin(r *http.Request) bool {
	c, err := r.Cookie("dardashat_admin")
	if err != nil {
		return false
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	until, ok := a.adminTokens[c.Value]
	if !ok || time.Now().After(until) {
		delete(a.adminTokens, c.Value)
		return false
	}
	return true
}
func (a *App) adminLogin(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Code string `json:"code"`
	}
	if !decode(w, r, &in) {
		return
	}
	a.mu.Lock()
	tooMany := a.rateFailedLocked("admin:" + remoteIP(r))
	a.mu.Unlock()
	if tooMany {
		problem(w, 429, "محاولات كثيرة، انتظر قليلاً")
		return
	}
	if subtle.ConstantTimeCompare([]byte(in.Code), []byte(a.adminCode)) != 1 {
		a.mu.Lock()
		a.failed["admin:"+remoteIP(r)] = append(a.failed["admin:"+remoteIP(r)], time.Now())
		a.mu.Unlock()
		problem(w, 403, "رمز الإدارة غير صحيح")
		return
	}
	tok := randText(32)
	a.mu.Lock()
	a.adminTokens[tok] = time.Now().Add(6 * time.Hour)
	a.mu.Unlock()
	http.SetCookie(w, &http.Cookie{Name: "dardashat_admin", Value: tok, Path: "/api/admin", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: 6 * 60 * 60, Secure: r.TLS != nil || strings.EqualFold(r.Header.Get("X-Forwarded-Proto"), "https")})
	writeJSON(w, 200, map[string]any{"ok": true})
}
func (a *App) adminStatus(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		problem(w, 405, "method")
		return
	}
	writeJSON(w, 200, map[string]any{"admin": a.checkAdmin(r)})
}
func (a *App) adminAction(w http.ResponseWriter, r *http.Request) {
	if !a.checkAdmin(r) {
		problem(w, 403, "غير مصرّح")
		return
	}
	var in struct {
		Action string `json:"action"`
		User   string `json:"user"`
		ID     int64  `json:"id"`
	}
	if !decode(w, r, &in) {
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	switch in.Action {
	case "kick", "ban":
		key := userKey(in.User)
		u, ok := a.store.Users[key]
		if !ok {
			problem(w, 404, "المستخدم غير موجود")
			return
		}
		if in.Action == "ban" {
			u.BannedUntil = time.Now().Add(30 * time.Minute).Unix()
			a.store.Users[key] = u
			if err := saveLocked(a); err != nil {
				problem(w, 500, "تعذر الحفظ")
				return
			}
		}
		for sid, s := range a.sessions {
			if s.User == key {
				delete(a.sessions, sid)
			}
		}
	case "delete":
		idx := -1
		for i, m := range a.store.Messages {
			if m.ID == in.ID {
				idx = i
				break
			}
		}
		if idx == -1 {
			problem(w, 404, "الرسالة غير موجودة")
			return
		}
		a.store.Messages = append(a.store.Messages[:idx], a.store.Messages[idx+1:]...)
		if err := saveLocked(a); err != nil {
			problem(w, 500, "تعذر الحفظ")
			return
		}
	default:
		problem(w, 400, "أمر إداري غير معروف")
		return
	}
	writeJSON(w, 200, map[string]any{"ok": true})
}
