const CACHE='dardashat-v2.2';
const FILES=['/','/index.html','/style.css','/app.js','/manifest.webmanifest','/icons/icon192.png','/icons/icon512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n!==CACHE).map(n=>caches.delete(n)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET'||new URL(r.url).pathname.startsWith('/api/'))return;
e.respondWith(fetch(r).then(res=>{if(res.ok&&new URL(r.url).origin===self.location.origin){const copy=res.clone();caches.open(CACHE).then(c=>c.put(r,copy))}return res}).catch(()=>caches.match(r).then(v=>v||new Response('غير متصل بالإنترنت. افتح دردشات عند توفر اتصال.',{headers:{'Content-Type':'text/plain; charset=utf-8'}}))))});
