package com.dardashat.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private String url;
    private TextView note;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        url = getString(R.string.chat_url);
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setBackgroundColor(0xFF090F23);
        note = new TextView(this);
        note.setTextColor(0xFFFFFFFF);
        note.setGravity(Gravity.CENTER);
        note.setTextSize(14);
        note.setPadding(20,16,20,16);
        view.addView(note, new LinearLayout.LayoutParams(-1,-2));
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF090F23);
        view.addView(webView, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(view);
        if (!url.startsWith("https://") || url.contains("example.com")) {
            note.setText("يجب نشر سيرفر دردشات وتعديل رابط chat_url في strings.xml قبل بناء APK.");
            return;
        }
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView,false);
        Uri base = Uri.parse(url);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("https".equals(u.getScheme()) && base.getHost().equalsIgnoreCase(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onPageFinished(WebView w, String u){note.setVisibility(View.GONE);}
            @Override public void onReceivedError(WebView w, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) { note.setVisibility(View.VISIBLE);note.setText("تعذر الاتصال بسيرفر دردشات. تحقق من الإنترنت والرابط."); }
            }
        });
        note.setText("جاري فتح دردشات...");
        webView.loadUrl(url);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
       if (webView != null) webView.destroy();
       super.onDestroy();
    }
}
