package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func setup(t *testing.T) (*App, *http.ServeMux) {
	t.Helper()
	dir := t.TempDir()
	a := &App{dir: dir, path: filepath.Join(dir, "data.json"), sessions: map[string]*Session{}, adminTokens: map[string]time.Time{}, adminCode: "admin-test", failed: map[string][]time.Time{}, store: Store{Users: map[string]User{}, Messages: []Msg{}, NextID: 1}}
	mux := http.NewServeMux()
	mux.HandleFunc("/api/auth", a.auth)
	mux.HandleFunc("/api/me", a.me)
	mux.HandleFunc("/api/logout", a.logout)
	mux.HandleFunc("/api/state", a.state)
	mux.HandleFunc("/api/send", a.send)
	mux.HandleFunc("/api/delete", a.deleteMessage)
	mux.HandleFunc("/api/admin/login", a.adminLogin)
	mux.HandleFunc("/api/admin/action", a.adminAction)
	mux.HandleFunc("/api/admin/status", a.adminStatus)
	return a, mux
}
func req(t *testing.T, mux http.Handler, method, path string, body any, cookie *http.Cookie) (int, map[string]any, *http.Cookie) {
	t.Helper()
	var b io.Reader
	if body != nil {
		raw, err := json.Marshal(body)
		if err != nil {
			t.Fatal(err)
		}
		b = bytes.NewReader(raw)
	}
	r := httptest.NewRequest(method, path, b)
	if body != nil {
		r.Header.Set("Content-Type", "application/json")
	}
	if cookie != nil {
		r.AddCookie(cookie)
	}
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, r)
	out := map[string]any{}
	if err := json.Unmarshal(w.Body.Bytes(), &out); err != nil {
		t.Fatal(err, "body:", w.Body.String())
	}
	var c *http.Cookie
	for _, ck := range w.Result().Cookies() {
		if ck.Name == "dardashat_sid" || ck.Name == "dardashat_admin" {
			c = ck
		}
	}
	return w.Code, out, c
}
func register(t *testing.T, mux http.Handler, name string) *http.Cookie {
	t.Helper()
	status, body, c := req(t, mux, "POST", "/api/auth", map[string]any{"name": name, "password": "verysecret"}, nil)
	if status != 200 || c == nil {
		t.Fatalf("registration %s => %d %#v", name, status, body)
	}
	return c
}
func TestRoomsPrivateAndPersistence(t *testing.T) {
	a, mux := setup(t)
	ali := register(t, mux, "علي")
	sara := register(t, mux, "سارة")
	ahmed := register(t, mux, "أحمد")
	_, _, _ = req(t, mux, "POST", "/api/send", map[string]any{"room": "العامة", "text": "أهلاً بالعامة", "to": ""}, ali)
	_, _, _ = req(t, mux, "POST", "/api/send", map[string]any{"room": "الألعاب", "text": "رسالة الألعاب", "to": ""}, sara)
	_, _, _ = req(t, mux, "POST", "/api/send", map[string]any{"room": "العامة", "text": "رسالة سرية", "to": "سارة"}, ali)
	code, st, _ := req(t, mux, "GET", "/api/state?room=العامة", nil, ahmed)
	if code != 200 {
		t.Fatal(code, st)
	}
	messages := st["messages"].([]any)
	if len(messages) != 1 || !strings.Contains(fmt.Sprint(messages), "أهلاً") {
		t.Fatal("room isolation", messages)
	}
	_, other, _ := req(t, mux, "GET", "/api/state?room=الألعاب", nil, ahmed)
	if len(other["messages"].([]any)) != 1 {
		t.Fatal("room 2 not isolated")
	}
	_, privateSara, _ := req(t, mux, "GET", "/api/state?room=العامة&peer=علي", nil, sara)
	if len(privateSara["messages"].([]any)) != 1 {
		t.Fatal("intended recipient cannot read", privateSara)
	}
	_, privateAhmed, _ := req(t, mux, "GET", "/api/state?room=العامة&peer=علي", nil, ahmed)
	if len(privateAhmed["messages"].([]any)) != 0 {
		t.Fatal("private leak!", privateAhmed)
	}
	raw, err := os.ReadFile(a.path)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Contains(raw, []byte("رسالة سرية")) {
		t.Fatal("persistence missing")
	}
	if bytes.Contains(raw, []byte("verysecret")) {
		t.Fatal("plaintext account password saved")
	}
}
func TestLimitTwentyAndBanning(t *testing.T) {
	_, mux := setup(t)
	cookies := []*http.Cookie{}
	for i := 0; i < 20; i++ {
		cookies = append(cookies, register(t, mux, fmt.Sprintf("مستخدم%02d", i)))
	}
	s, resp, _ := req(t, mux, "POST", "/api/auth", map[string]any{"name": "الحادي والعشرون", "password": "verysecret"}, nil)
	if s != 403 {
		t.Fatal("should reject over capacity", s, resp)
	}
	_, _, adminCookie := req(t, mux, "POST", "/api/admin/login", map[string]any{"code": "admin-test"}, nil)
	if adminCookie == nil {
		t.Fatal("admin login failed")
	}
	s, body, _ := req(t, mux, "POST", "/api/admin/action", map[string]any{"action": "ban", "user": "مستخدم01"}, adminCookie)
	if s != 200 {
		t.Fatal(s, body)
	}
	s, _, _ = req(t, mux, "GET", "/api/me", nil, cookies[1])
	if s != 401 {
		t.Fatal("banned user remains logged in")
	}
	s, resp, _ = req(t, mux, "POST", "/api/auth", map[string]any{"name": "جديد بعد الطرد", "password": "verysecret"}, nil)
	if s != 200 {
		t.Fatal("slot not freed", s, resp)
	}
}
func TestDuplicateSessionsAndRateLimit(t *testing.T) {
	_, mux := setup(t)
	old := register(t, mux, "بلال")
	newer := register(t, mux, "بلال")
	_, _ = newer, newer
	s, _, _ := req(t, mux, "GET", "/api/me", nil, old)
	if s != 401 {
		t.Fatal("old session should expire")
	}
	for i := 0; i < 5; i++ {
		_, _, _ = req(t, mux, "POST", "/api/send", map[string]any{"room": "العامة", "text": "رسالة"}, newer)
	}
	s, resp, _ := req(t, mux, "POST", "/api/send", map[string]any{"room": "العامة", "text": "رسالة"}, newer)
	if s != 429 {
		t.Fatal("rate limiting missing", s, resp)
	}
}
